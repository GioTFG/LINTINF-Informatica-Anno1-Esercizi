#!/usr/bin/env python3
"""
@author  Michele Tomaiuolo - https://tomamic.github.io/
@license This software is free - https://opensource.org/license/mit
"""

user = input("User? ")
print("Welcome,", user, "!")
if user == "admin":
    print("At your command")
