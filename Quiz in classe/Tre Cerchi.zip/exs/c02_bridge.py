#!/usr/bin/env python3
"""
@author  Michele Tomaiuolo - https://tomamic.github.io/
@license This software is free - https://opensource.org/license/mit
"""

name = input("What is your name? ")
quest = input("What is your quest? ")
color = input("What is your favorite color? ")

if name == "Lancelot" and quest == "Holy Grail" and color == "Blue":
    print("Right. Off you go.")
else:
    print("Down into the Gorge of Ethernal Peril!")
