#!/usr/bin/env python3
"""
@author  Michele Tomaiuolo - https://tomamic.github.io/
@license This software is free - https://opensource.org/license/mit
"""

a = float(input("1st val? "))
b = float(input("2nd val? "))
c = float(input("3rd val? "))

total = a + b + c
print("The sum is ", total)
