#!/usr/bin/env python3
"""
@author  Michele Tomaiuolo - https://tomamic.github.io/
@license This software is free - https://opensource.org/license/mit
"""

for y in range(1, 11):
    for x in range(1, 11):
        print(x * y, end="\t")
    print()
