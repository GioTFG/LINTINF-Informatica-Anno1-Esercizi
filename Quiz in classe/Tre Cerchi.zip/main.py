# Programma scritto interamente da Ancora Giovanni, il 22/09/2025.

import g2d
from random import randrange

g2d.init_canvas( (500, 500) )

raggio1 = float(g2d.prompt("Inserisci il primo raggio: "))
g2d.set_color( (randrange(256), randrange(256), randrange(256)) )
g2d.draw_circle( (250, 250), raggio1 )

# Immagino che non vogliamo che i cerchi "oscurino" quelli disegnati precedentemente.
# Permetterò di farlo, ma ho voluto aggiungere un alert che avvisi qualora qualcosa del genere accadesse.

raggio2 = float(g2d.prompt("Inserisci il secondo raggio: "))
g2d.set_color( (randrange(256), randrange(256), randrange(256)) )
g2d.draw_circle( (250, 250), raggio2 )

if raggio2 >= raggio1:
    g2d.alert("Il primo cerchio verrà oscurato dal secondo.")

raggio3 = float(g2d.prompt("Inserisci il terzo raggio: "))
g2d.set_color( (randrange(256), randrange(256), randrange(256)) )
g2d.draw_circle( (250, 250), raggio3 )

if raggio3 >= raggio1:
    g2d.alert(f"Il primo cerchio verrà oscurato dal terzo.")

if raggio3 >= raggio2:
    g2d.alert("Il secondo cerchio verrà oscurato dal terzo.")


g2d.main_loop()